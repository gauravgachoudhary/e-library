<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>E-library||Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/log_sign.css">
    <link rel="stylesheet" href="CSS/book.css">
    <link rel="shortcut icon" href="IMAGE/favicon.ico" type="image/x-icon">
</head>
<body>

        <div class="header">
            <div class="header_name">
                <h1>E-library</h1>
            </div>
            <div class="nav">
             <?php 
                if(isset($_SESSION['Name']))
                {
                    echo
                    "
                    <ul>
                        <a href='index.php'><li>HOME</li></a>
                        <a href='profile.php'> <li>PROFILE</li></a>
                        <a href='#'> <li>FEATURE</li></a>
                       
                    </ul>
                    ";

                }
                else
                {
                    echo
                    "
                    <ul>
                        <a href='index.php'><li>HOME</li></a>
                       
                        <a href='#'> <li>FEATURE</li></a>
                        <a href='login.php'><li>LOGIN</li></a>
                    </ul>
                    ";
                }
             ?>
                
            </div>

            <br clear="all">

        </div>

        <div class='login_n'>
            <p>Book Detail</p>
        </div>

        <div class="book_img">
            <img src="IMAGE/b1.jpg" alt="Book Image" >
        </div>

        <div class="book_disc_">
            <p>Book Name</p>
            <p>Author Name</p>
            <p>Edition</p>
            <p>Describtion</p>
        </div>
        <br clear="all"> 

        <!-- Download or View Book -->
        <span>h</span>
        <a class="view" href="upload/book1381772923.pdf#toolbar=0" target="null" >
            <p>View Book</p>
        </a>

        <a class="view" href="upload/book1381772923.pdf#toolbar=0" target="null" Download>
            <p>Download Book</p>
        </a>
        <br clear="all">
        
        <?php
            include_once 'footer.php';
        ?>
</body>
</html>